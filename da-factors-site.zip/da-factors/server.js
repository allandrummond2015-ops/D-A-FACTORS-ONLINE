// D&A Factors parts site: static files + API routes.
//   GET  /api/vehicles          -> makes, models and engines (data/vehicles.json)
//   GET  /api/parts?engine=&year= -> parts that fit, from the supplier price file + data/fitment.csv
//   POST /api/search            -> AI parts search (Claude API, key stays on the server)
// The catalogue reloads by itself when anything in data/ changes.
// Run: ANTHROPIC_API_KEY=... npm start
import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import Anthropic from "@anthropic-ai/sdk";
import { betaZodOutputFormat } from "@anthropic-ai/sdk/helpers/beta/zod";
import { z } from "zod";
import { load } from "./lib/catalogue.js";
import fsSync from "node:fs";

const here = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(here, "public");
const DATA = path.join(here, "data");
const PORT = Number(process.env.PORT) || 3000;

let client = null;
try { client = new Anthropic(); } catch { client = null; } // no credentials: AI search reports unavailable

let catalogue = null;
async function reloadCatalogue() {
  try {
    const next = await load(DATA);
    catalogue = next;
    const r = next.report;
    console.log(`Catalogue loaded: ${r.partCount} parts from ${r.files.map(f => f.name).join(", ")}, ${r.fitmentRows} fitment rows` +
      (r.unlinkedParts.length ? `, ${r.unlinkedParts.length} parts not linked to any vehicle` : "") +
      (Object.keys(r.skipped).length ? `, skipped ${JSON.stringify(r.skipped)}` : ""));
    r.warnings.forEach(w => console.warn("  " + w));
  } catch (err) {
    console.error(`Catalogue not updated: ${err.message}${catalogue ? " (still serving the previous one)" : ""}`);
  }
}
await reloadCatalogue();
let reloadTimer;
fsSync.watch(DATA, { recursive: true }, () => { clearTimeout(reloadTimer); reloadTimer = setTimeout(reloadCatalogue, 1500); });

const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml", ".json": "application/json", ".ico": "image/x-icon" };

const SearchResult = z.object({
  summary: z.string(),
  picks: z.array(z.object({ id: z.string(), why: z.string() })),
  advice: z.string(),
  followUp: z.string(),
});

const SYSTEM = `You are the parts advisor at the trade counter of D&A Factors, a motor factors in Dundee.
You are given the customer's vehicle, the list of parts in the catalogue that fit it, and the customer's request.
Pick up to 6 parts from the list that best answer the request, most relevant first. Use only ids from the list.
If the request describes a symptom, say briefly what usually causes it on this kind of car.
If brakes, steering or suspension safety is involved, recommend a professional check.
If nothing in the list fits, return no picks and say what to search for instead, or suggest phoning the counter on 01382 228202.
summary: 1-2 plain sentences. why: under 15 words. advice and followUp: one sentence each, or an empty string.`;

async function readJson(req, limit = 200_000) {
  let body = "";
  for await (const chunk of req) {
    body += chunk;
    if (body.length > limit) throw Object.assign(new Error("Request too large"), { status: 413 });
  }
  return JSON.parse(body || "{}");
}
const send = (res, status, obj) => { res.writeHead(status, { "content-type": "application/json" }); res.end(JSON.stringify(obj)); };

async function handleSearch(req, res) {
  if (!client) return send(res, 503, { error: "ai_unavailable" });
  const { query, vehicle, engine, year } = await readJson(req);
  const parts = catalogue?.partsFor(String(engine), Number(year) || null);
  if (typeof query !== "string" || !query.trim() || query.length > 500 || typeof vehicle !== "string" || vehicle.length > 300 || !parts) {
    return send(res, 400, { error: "bad_request" });
  }
  const lines = parts.slice(0, 300).map(p => [p.id, p.cat, p.name, p.brand, `£${p.inc.toFixed(2)}`, p.note, p.stock.t].join(" | ")).join("\n");
  try {
    const response = await client.beta.messages.parse({
      model: "claude-opus-5-5",
      max_tokens: 4000,
      betas: ["server-side-fallback-2026-07-01"],
      fallbacks: "default",
      output_config: { effort: "low", format: betaZodOutputFormat(SearchResult) },
      system: SYSTEM,
      messages: [{
        role: "user",
        content: `Vehicle: ${vehicle}\n\nParts that fit (id | category | name | brand | price inc VAT | note | stock):\n${lines}\n\nCustomer request: ${query}`,
      }],
    });
    if (response.stop_reason === "refusal" || !response.parsed_output) return send(res, 422, { error: "no_answer" });
    const ids = new Set(parts.map(p => String(p.id)));
    const out = response.parsed_output;
    out.picks = out.picks.filter(p => ids.has(p.id)).slice(0, 6);
    send(res, 200, out);
  } catch (err) {
    if (err instanceof Anthropic.RateLimitError) return send(res, 429, { error: "rate_limited" });
    if (err instanceof Anthropic.AuthenticationError) return send(res, 503, { error: "ai_unavailable" });
    if (err instanceof Anthropic.APIError) { console.error("Claude API error", err.status, err.message); return send(res, 502, { error: "upstream" }); }
    // Anything else (usually no credentials configured): switch AI search off until restart.
    console.error("AI search disabled:", err.message);
    client = null;
    return send(res, 503, { error: "ai_unavailable" });
  }
}

async function serveStatic(res, pathname) {
  const file = path.normalize(path.join(PUBLIC, pathname === "/" ? "index.html" : pathname));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
  try {
    const data = await fs.readFile(file);
    res.writeHead(200, { "content-type": TYPES[path.extname(file)] || "application/octet-stream" });
    res.end(data);
  } catch { res.writeHead(404); res.end("Not found"); }
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  try {
    if (url.pathname === "/api/search" && req.method === "POST") return await handleSearch(req, res);
    if (url.pathname === "/api/vehicles") return catalogue ? send(res, 200, catalogue.vehicles) : send(res, 503, { error: "catalogue_unavailable" });
    if (url.pathname === "/api/parts") {
      if (!catalogue) return send(res, 503, { error: "catalogue_unavailable" });
      const parts = catalogue.partsFor(url.searchParams.get("engine") || "", Number(url.searchParams.get("year")) || null);
      return parts ? send(res, 200, parts) : send(res, 404, { error: "unknown_vehicle" });
    }
    if (url.pathname === "/api/catalogue") {
      const r = catalogue?.report;
      return send(res, 200, r ? { updated: r.updated, parts: r.partCount, sample: r.sample } : {});
    }
    if (url.pathname === "/api/status") return send(res, 200, { ai: !!client });
    if (req.method === "GET") return await serveStatic(res, decodeURIComponent(url.pathname));
    res.writeHead(405); res.end();
  } catch (err) {
    console.error(err);
    if (!res.headersSent) send(res, err.status || 500, { error: "server_error" });
  }
}).listen(PORT, () => console.log(`D&A Factors parts site on http://localhost:${PORT}  (AI search: ${client ? "on" : "off"})`));
