# D&A Factors parts site

Car parts ordering site for D&A Factors, Dundee (01382 228202). Customers choose their vehicle (make, model, year, engine), then search by part name, part number or a description of the fault. They order for click & collect or delivery.

## Run it

```bash
npm install
```

```bash
ANTHROPIC_API_KEY=sk-ant-... npm start
```

Open http://localhost:3000. Without `ANTHROPIC_API_KEY` the site still works, with keyword search only.

## Demo version

```bash
npm run build-demo
```

This writes `demo/da-factors-demo.html`, a single file with the logo, vehicles and parts built in. It opens in any browser with no server, so you can email it or open it on a laptop to show people. The demo has keyword search only (AI search needs the server), and it uses whatever is in `data/` when you build it.

## Updating prices: the supplier price file

Put your supplier price files in `data/prices/`. They can be `.csv` or `.xlsx`, for example the NAPA file and the MAHLE file side by side. The site combines every file in that folder. If the same part number appears in two files, the newer file's price wins.

The site reloads within a couple of seconds whenever a file in `data/` changes, so there's no need to restart it. If a new file can't be read, the site keeps serving the previous prices and prints the problem in the server log.

Before replacing the files on the live site, check them:

```bash
npm run check-prices
```

The check shows which columns it used, how many parts loaded, and which rows it skipped and why. It also lists parts that aren't linked to any vehicle (these don't appear on the site).

### Columns

The site finds these columns by their usual names. The header row can be anywhere in the first 10 rows.

| Field | Recognised headers (examples) | Needed? |
|---|---|---|
| Part number | Part No, Part Number, Product Code, Item Code, SKU, Stock Code | Yes |
| Price | Trade Price, Net Price, Cost, Price (and/or RRP, Retail Price, List Price) | Yes, one of them |
| Description | Description, Item Description, Product Name | Recommended |
| Brand | Brand, Manufacturer | Recommended |
| Stock | Free Stock, Stock, Qty, Available | Optional ("Call to check stock" if missing) |
| Product group | Product Group, Category, Line | Optional (helps sort parts into categories) |

If your file uses a different header, name it in `data/settings.json`, for example `"columns": {"cost": "Our Nett", "partNumber": "Cat No"}`.

### Pricing rules (`data/settings.json`)

- `useRrpWhenGiven` (true): sell at RRP when the file has one.
- `markupPercent` (45): otherwise sell at trade price plus this markup.
- `pricesIncludeVat` (false): set to true if the file's prices already include VAT.
- `lowStockAt` (3): show "Low stock" at this quantity or below.

The site shows prices including VAT, with the ex-VAT price beside them.

## Which parts fit which car: `data/fitment.csv`

Price files don't say which cars a part fits, so that lives in `data/fitment.csv`, one row per part per vehicle:

| part_number | make | model | engine_code | year_from | year_to | note |
|---|---|---|---|---|---|---|
| 12345 | Ford | Focus Mk4 | M1DA | 2018 | 2025 | Front axle · 278 mm discs |
| 67890 | Ford | Focus Mk4 | | 2018 | 2025 | All Focus Mk4 engines |
| 55555 | * | | | | | Fits all vehicles (e.g. bulbs, fluids) |

`engine_code` is the code in `vehicles.json` (e.g. `M1DA`), or the engine's `id` where no code is listed. Leave `engine_code` blank for all engines, and leave the years blank for all years. `make` set to `*` means every vehicle. The makes, models and engines customers can pick from are in `data/vehicles.json`: currently 21 makes, 60 models and 120 engines, covering the cars most common on UK roads. Engine codes, timing (belt or chain) and disc sizes are filled in only where confirmed; blank ones are hidden on the site.

To fill fitment for thousands of parts, use a licensed fitment catalogue such as TecDoc (TecAlliance), or the fitment export your distributor provides, saved in this format.

## Files

- `server.js`: web server and API (`/api/vehicles`, `/api/parts`, `/api/search`).
- `lib/catalogue.js`: reads the price files, fitment and vehicles, and joins them.
- `scripts/check-prices.js`: the `npm run check-prices` report.
- `scripts/build-demo.js`: the `npm run build-demo` single-file demo.
- `public/index.html`: the storefront. `public/logo.png`: the D&A logo.
- `data/`: price files, fitment, vehicles and settings.

## Before going live

1. Replace `data/prices/SAMPLE-supplier-price-file.csv` and `data/fitment.csv` with your real data. The sample part numbers (`SMP…`) and prices are made up for testing, and while the sample file is present the footer says "Preview build".
2. Checkout only shows a confirmation. Connect a payment provider and send orders to your counter system or email.
