// Reads data/ exactly as the site does and prints what it found. Run: npm run check-prices
import path from "node:path";
import { fileURLToPath } from "node:url";
import { load } from "../lib/catalogue.js";

const dataDir = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "data");
const list = (label, items) => {
  if (!items.length) return;
  console.log(`\n${label} (${items.length}):`);
  items.slice(0, 15).forEach(i => console.log("  " + i));
  if (items.length > 15) console.log(`  …and ${items.length - 15} more`);
};

try {
  const { report: r, vehicles } = await load(dataDir);
  for (const f of r.files) {
    console.log(`Price file:   ${f.name}${/sample/i.test(f.name) ? "  (SAMPLE DATA)" : ""}: ${f.parts} parts`);
    console.log(`  columns:    ${Object.entries(f.columns).map(([k, h]) => `${k} = "${h}"`).join(", ")}`);
  }
  console.log(`Parts loaded: ${r.partCount}${r.files.length > 1 ? " (newer files override older ones for the same part number)" : ""}`);
  console.log(`Fitment rows: ${r.fitmentRows} (vehicles listed: ${vehicles.reduce((n, m) => n + m.models.length, 0)} models)`);
  for (const [why, n] of Object.entries(r.skipped)) console.log(`Skipped:      ${n} rows with ${why}`);
  r.warnings.forEach(w => console.log(`Warning:      ${w}`));
  list("Parts in the price file with no fitment, so not shown on the site", r.unlinkedParts);
  list("Part numbers in fitment.csv that aren't in the price file", r.unknownFitmentParts);
  list("Vehicles in fitment.csv that aren't in vehicles.json", r.unknownVehicles);
} catch (err) {
  console.error("Problem: " + err.message);
  process.exit(1);
}
