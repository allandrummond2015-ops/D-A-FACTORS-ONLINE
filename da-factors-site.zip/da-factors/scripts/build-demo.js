// Builds demo/da-factors-demo.html: the storefront as one file with the logo, vehicles and parts
// built in, so it opens straight from disk with no server. Run: npm run build-demo
// Also writes demo/da-factors-artifact.html, the same page shaped for publishing on claude.ai,
// where the AI parts search runs on the viewer's own Claude account.
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { load } from "../lib/catalogue.js";

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const catalogue = await load(path.join(root, "data"));
const data = { vehicles: catalogue.vehicles, ...catalogue.dump(), updated: catalogue.report.updated };
const logo = "data:image/png;base64," + (await fs.readFile(path.join(root, "public/logo.png"))).toString("base64");

// Answers the page's api/ calls from the embedded data. Mirrors partsFor() in lib/catalogue.js.
const shim = `<script>
(()=>{
const D=${JSON.stringify(data).replace(/</g, "\\u003c")};
const key=s=>String(s??"").toLowerCase().replace(/[^a-z0-9]/g,"");
const parts=new Map(D.parts.map(p=>[p.id,p])), eng=new Map();
for(const mk of D.vehicles)for(const m of mk.models)for(const e of m.engines)eng.set(e.id,{e,m});
function partsFor(id,year){
  const h=eng.get(id); if(!h) return null;
  const out=new Map();
  for(const f of D.fitment){
    if(f.models&&!f.models.includes(h.m.id)) continue;
    if(f.engineCode&&f.engineCode!==key(h.e.code)&&f.engineCode!==key(h.e.id)) continue;
    if(year&&((f.from&&year<f.from)||(f.to&&year>f.to))) continue;
    if(!out.has(f.k)) out.set(f.k,{...parts.get(f.k),note:f.note});
  }
  return [...out.values()];
}
const reply=(o,status=200)=>Promise.resolve(new Response(JSON.stringify(o),{status,headers:{"content-type":"application/json"}}));
const realFetch=window.fetch.bind(window);
window.fetch=(url,opts)=>{
  const u=String(url);
  if(!u.startsWith("api/")) return realFetch(url,opts);
  const q=new URLSearchParams(u.split("?")[1]||"");
  if(u.startsWith("api/vehicles")) return reply(D.vehicles);
  if(u.startsWith("api/parts")){const p=partsFor(q.get("engine")||"",Number(q.get("year"))||null);return p?reply(p):reply({error:"unknown_vehicle"},404)}
  if(u.startsWith("api/catalogue")) return reply({updated:D.updated,parts:D.parts.length,sample:true});
  if(u.startsWith("api/status")) return getSample().then(s=>reply({ai:!!s}));
  if(u.startsWith("api/search")) return aiSearch(JSON.parse(opts?.body||"{}"));
  return reply({error:"not_found"},404);
};
// AI search inside a Claude viewer; absent anywhere else (window.claude missing), so keyword search only.
let samplePromise=null;
const getSample=()=>samplePromise??=(window.claude?.use?window.claude.use("sample").catch(()=>null):Promise.resolve(null));
const RULES="You are the parts advisor at the trade counter of D&A Factors, a motor factors in Dundee. Pick up to 6 parts from the list that best answer the customer's request, most relevant first. Use only ids from the list. If the request describes a symptom, say briefly what usually causes it on this kind of car. If brakes, steering or suspension safety is involved, recommend a professional check. If nothing in the list fits, return no picks and say what to search for instead, or suggest phoning the counter on 01382 228202.";
async function aiSearch({query,vehicle,engine,year}){
  const sample=await getSample();
  if(!sample) return reply({error:"ai_unavailable"},503);
  const list=partsFor(String(engine),Number(year)||null);
  if(!list||typeof query!=="string"||!query.trim()) return reply({error:"bad_request"},400);
  const lines=list.map(p=>[p.id,p.cat,p.name,p.brand,"£"+p.inc.toFixed(2),p.note,p.stock.t].join(" | ")).join("\\n");
  const prompt=RULES+"\\n\\nVehicle: "+String(vehicle).slice(0,300)+"\\n\\nParts that fit (id | category | name | brand | price inc VAT | note | stock):\\n"+lines+
    "\\n\\nCustomer request: "+query.slice(0,500)+
    '\\n\\nReply with only JSON: {"summary":"1-2 plain sentences","picks":[{"id":"...","why":"under 15 words"}],"advice":"one sentence or empty string","followUp":"one question or empty string"}';
  try{
    const r=await sample.json(prompt,{modelTier:"quick"});
    const ids=new Set(list.map(p=>p.id));
    const picks=(Array.isArray(r?.picks)?r.picks:[]).filter(x=>ids.has(String(x?.id))).slice(0,6).map(x=>({id:String(x.id),why:String(x.why||"")}));
    return reply({summary:String(r?.summary||""),picks,advice:String(r?.advice||""),followUp:String(r?.followUp||"")});
  }catch(e){
    if(e?.code==="not_granted"||e?.code==="sampling_disabled"||e?.code==="not_declared"){samplePromise=Promise.resolve(null);return reply({error:"ai_unavailable"},503)}
    if(e?.code==="rate_limited") return reply({error:"rate_limited"},429);
    if(e?.code==="refused"||e?.code==="invalid_json"||e?.code==="empty_completion") return reply({error:"no_answer"},422);
    return reply({error:"upstream"},502);
  }
}
})();
</script>
`;

let html = await fs.readFile(path.join(root, "public/index.html"), "utf8");
html = html.replaceAll('src="logo.png"', `src="${logo}"`).replace('href="logo.png"', `href="${logo}"`);
html = html.replace("<title>D&amp;A Factors | Car Parts, Dundee</title>", "<title>D&amp;A Factors | Car Parts (Demo)</title>");
const at = html.lastIndexOf("<script>");
html = html.slice(0, at) + shim + html.slice(at);
await fs.mkdir(path.join(root, "demo"), { recursive: true });
const out = path.join(root, "demo/da-factors-demo.html");
await fs.writeFile(out, html);
// claude.ai wraps a published page in its own document, so the artifact copy is the body content only:
// title, styles and markup, without the doctype/head/body wrapper or the safe-area padding it already adds.
const artifact = html
  .replace(/^<!doctype html>\s*<html[^>]*>\s*<head>\s*<meta charset="utf-8">\s*<meta name="viewport"[^>]*>\s*/i, "")
  .replace("<title>D&amp;A Factors | Car Parts (Demo)</title>", '<title>D&amp;A Factors Parts Demo</title>\n<meta name="claude:viewport-fit-sides" content="cover">')
  .replace(":root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}", "")
  .replace(/<\/style>\s*<\/head>\s*<body>/, "</style>")
  .replace(/<\/body>\s*<\/html>\s*$/, "\n");
await fs.writeFile(path.join(root, "demo/da-factors-artifact.html"), artifact);
console.log(`Wrote ${path.relative(root, out)} (${(html.length / 1024).toFixed(0)} KB, ${data.parts.length} parts, ${catalogue.vehicles.length} makes)`);
